package com.example.completepokemondex.util

class Constants {
    // Constantes (URLs, etc.)
}