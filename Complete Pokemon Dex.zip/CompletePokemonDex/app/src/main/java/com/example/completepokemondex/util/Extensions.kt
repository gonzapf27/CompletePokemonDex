package com.example.completepokemondex.util

class Extensions {
    // Funciones de extensión reutilizables
}